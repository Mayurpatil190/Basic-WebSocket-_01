<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generate and Send Random Number</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

<button id="startBtn">Start Generating Random Number Every 2 Seconds</button>
<button id="stopBtn" style="display:none;">Stop Generating</button>

<script>
let intervalId;

function startGenerating() {
    intervalId = setInterval(function() {
        const randomNumber = Math.floor(Math.random() * 1000) + 1; // Generate random number between 1 and 1000
        console.log("Random number: " + randomNumber);
        
        // Send the generated random number to the server using AJAX
        $.ajax({
            type: 'POST',
            url: '<?php echo $_SERVER['PHP_SELF']; ?>',
            data: { randomNumber: randomNumber },
            success: function(response) {
                console.log(response); // Log the response from the server
            }
        });
        
    }, 2000);
    document.getElementById('startBtn').style.display = 'none';
    document.getElementById('stopBtn').style.display = 'block';
}

function stopGenerating() {
    clearInterval(intervalId);
    document.getElementById('startBtn').style.display = 'block';
    document.getElementById('stopBtn').style.display = 'none';
}

document.getElementById('startBtn').addEventListener('click', startGenerating);
document.getElementById('stopBtn').addEventListener('click', stopGenerating);
</script>

<?php
if(isset($_POST['randomNumber']) && $_POST['randomNumber']!=''){
    // Retrieve the random number sent from the client
    $randomNumber = $_POST['randomNumber'];
    
    // Assuming your socket server logic here
    $host = "127.0.0.1";
    $port = 80811;
    $socket = socket_create(AF_INET, SOCK_STREAM, 0) or die('Socket creation failed');
    socket_connect($socket, $host, $port) or die('Socket connection failed');
    socket_write($socket, $randomNumber, strlen($randomNumber));
    socket_close($socket);
    
    // Send a response back to the client
    // echo "<script>console.log('Random number sent successfully to the server: $randomNumber')";
    echo "Random number sent successfully to the server: $randomNumber";
}
?>
</script>

</body>
</html>
